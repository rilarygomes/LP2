﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;



namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string input = "";
            for (var i = 0; i < vetor.Length; i++)
            {
                input = Interaction.InputBox("Entre com o valor: " + (i + 1).ToString(),
                    "Entrada de Dados");
                if (!int.TryParse(input, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }

            input = "";

            for (var i = vetor.Length - 1; i >= 0; i--)
                input += "\n" + vetor[i].ToString();

            MessageBox.Show(input);

        

        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];

            string input = "";
            for (var i = 0; i < vetor.Length; i++)
            {
                input = Interaction.InputBox("Entre com o valor: " + (i + 1).ToString(),
                    "Entrada de Dados");
                if (!int.TryParse(input, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }

            Array.Reverse(vetor);

            input = "";

            for (int i = vetor.Length - 1; i >= 0; i--)
            {
                input += vetor[i].ToString() + "\n";
            }

            MessageBox.Show(input);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[] qtd = new double[10];
            double[] val = new double[10];

            bool qtdCorreta = false;

            string input = "";

            for (int i = 0; i < qtd.Length; i++)
            {
                if (!qtdCorreta)
                {
                    input = Interaction.InputBox("Digite a quantidade do produto " + (i + 1).ToString() + ": ");

                    if (!(double.TryParse(input, out qtd[i])))
                    {
                        MessageBox.Show("Quantidade inválida!");
                        i--;
                    }
                    else
                    {
                        qtdCorreta = true;
                    }
                }

                input = Interaction.InputBox("Digite o valor do produto " + (i + 1).ToString() + ": ");

                if (!(double.TryParse(input, out val[i])))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
                else
                {
                    qtdCorreta = false;
                }
            }

            double faturament = 0;

            for (int i = 0; i < qtd.Length; i++)
            {
                faturament += qtd[i] * val[i];
            }

            MessageBox.Show("Faturamento do mês: R$ " + faturament.ToString("N2"));
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };

            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show("O total é: " + Total.ToString());
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            ArrayList arry = new ArrayList();

            arry.Add("Ana");
            arry.Add("André");
            arry.Add("Débora");
            arry.Add("Fátima");
            arry.Add("João");
            arry.Add("Janete");
            arry.Add("Otávio");
            arry.Add("Marcelo");
            arry.Add("Pedro");
            arry.Add("Thais");

            arry.Remove("Otávio");

            string text = "";

            for (int i = 0; i < arry.Count; i++)
            {
                text += arry[i] + "\n";
            }

            MessageBox.Show(text);
        }

        private void btnEx6_Click(object sender, EventArgs e)
        {
            double[,] nota = new double[20, 3];

            string auxiliar = "";

            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota " + (j + 1).ToString() + 
                        " do aluno " + (i + 1).ToString());

                    if (!(double.TryParse(auxiliar, out nota[i, j])))
                    {
                        MessageBox.Show("Valor de nota inválido!");
                        j--;
                    }
                }
            }

            auxiliar = "";

            for (int i = 0; i < 20; i++)
            {
                auxiliar += "Aluno " + (i + 1).ToString() + ": média " +
                    ((nota[i, 0] + nota[i, 1] + nota[i, 2]) / 3).ToString("N2") + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnEx7_Click(object sender, EventArgs e)
        {

            Form fc = Application.OpenForms["Form2"];

            if (fc != null)
            {
                fc.Close();
            }

            Form2 frm = new Form2();
            frm.Show();
        }
    }
}
