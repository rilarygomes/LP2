﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            string[] nome = new string[1];
            int[] qtdeChar = new int[1];
            string auxiliar = "";

            for (int i = 0; i < nome.Length; i++)
            {
                auxiliar = Interaction.InputBox("Digite o nome completo:");

                if (auxiliar != "")
                {
                    nome[i] = auxiliar;
                    auxiliar = nome[i].Replace(" ", "");
                    qtdeChar[i] = auxiliar.Length;

                    listBox1.Items.Add("O nome " + nome[i] + " tem " + qtdeChar[i] + " caracteres.");
                }
                else
                {
                    MessageBox.Show("Nome não pode estar em branco!");
                    i--;
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
