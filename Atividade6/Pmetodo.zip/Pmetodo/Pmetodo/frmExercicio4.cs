﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodo
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int numeros = 0;
            for (contador = 0; contador < rchTxt.Text.Length; contador++)
            {
                if (Char.IsNumber(rchTxt.Text[contador]))

                {
                    numeros += 1;
                }
            }
            MessageBox.Show("A quantidade de números é:" + numeros.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int posicaoBranco = 0;
            while (contador < rchTxt.Text.Length)
            {
                if (Char.IsWhiteSpace(rchTxt.Text[contador]))
                {
                    posicaoBranco = contador + 1;
                    break;
                }
                contador++;
            }
            MessageBox.Show("O primeiro caracter branco está na posição:" +
                posicaoBranco.ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char chara in rchTxt.Text)
            {
                if (Char.IsLetter(chara))
                {
                    contador += 1;
                }
            }
            MessageBox.Show("O texto tem " + contador.ToString() +
                " caracteres alfabéticos");

        }
    }
}
