﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482013041
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lbxResultado.Items.Clear();
            
            double[,] meses = new double[8, 4];
            string valSemana;
            double TotalMes = 0;
            double TotTotal = 0;


            for (int mes = 0; mes < 8; mes++)
            {
                for (int semana = 0; semana < 4; semana++)
                {
                    valSemana = Interaction.InputBox("Insira o valor recebido na semana " + (semana + 1) + " do mes " + (mes + 1), "Digite os valores", "0");
                    double valor;
                    try
                    {
                        valor = Double.Parse(valSemana);
                        meses[mes, semana] = valor;
                        TotalMes += valor;
                        TotTotal += valor;

                    }
                    catch
                    {
                        MessageBox.Show("Valor Inválido!");
                        valor = 0;
                    }
                    lbxResultado.BeginUpdate();

                    lbxResultado.Items.Add("Total do Mês: " + (mes + 1) + " Semana " + (semana + 1) + " = " + String.Format("{0:C2}", valor));

                    lbxResultado.EndUpdate();
                }

                lbxResultado.BeginUpdate();

                lbxResultado.Items.Add(">> Total do mês: " + String.Format("{0:C2}", TotalMes));
                lbxResultado.Items.Add("--------------------------------");
                lbxResultado.EndUpdate();
                TotalMes = 0;
            }

            lbxResultado.BeginUpdate();
            lbxResultado.Items.Add(">> Total Geral: " + String.Format("{0:C2}", TotTotal));
            lbxResultado.Items.Add("-------------------------------");
            lbxResultado.EndUpdate();
            TotTotal = 0;

        }
    }
}


