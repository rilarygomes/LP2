﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ploops
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnContBranco_Click(object sender, EventArgs e)
        {
            int contEsp = 0;

            foreach (char c in rchTxt1.Text.ToUpper())
            {
                if (Char.ToUpper(c) == ' ')
                    contEsp++;
            }
            MessageBox.Show("O número de espaços em branco é: " + contEsp.ToString());
        }

        private void btnContR_Click(object sender, EventArgs e)
        {
            int contR = 0;
            for (int i = 0; i < rchTxt1.Text.Length; i++)
            {
                if (rchTxt1.Text[i] == 'r' || rchTxt1.Text[i] == 'R')
                    contR++;
            }
            MessageBox.Show("O número de letras R é: " + contR.ToString());
        }

        private void btnContPar_Click(object sender, EventArgs e)
        {
            int contRep = 0;
            char LetraAnt = '\0';
            foreach (char c in rchTxt1.Text)
            {
                if (Char.ToUpper(c) == LetraAnt)
                {
                    contRep++;
                }
                LetraAnt = Char.ToUpper(c);
            }
            MessageBox.Show("O número de letras repetidas é: " + contRep.ToString());
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
